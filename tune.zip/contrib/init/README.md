Sample configuration files for:

SystemD: tuned.service
Upstart: tuned.conf
OpenRC:  tuned.openrc
         tuned.openrcconf
CentOS:  tuned.init
OS X:    org.tune.tuned.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
